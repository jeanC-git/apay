@extends('layouts.app')
@section('content')
    <informacion></informacion>
@endsection