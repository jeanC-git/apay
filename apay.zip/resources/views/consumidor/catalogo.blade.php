@extends('layouts.app')
@section('content')
    <catalogo></catalogo>
@endsection