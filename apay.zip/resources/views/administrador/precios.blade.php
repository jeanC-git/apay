@extends('layouts.app')
@section('content')
    <precios-admin></precios-admin>
@endsection