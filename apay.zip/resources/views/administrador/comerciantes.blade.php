@extends('layouts.app')
@section('content')
    <comerciantes></comerciantes>    
@endsection