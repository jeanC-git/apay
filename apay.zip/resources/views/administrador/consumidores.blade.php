@extends('layouts.app')
@section('content')
    <consumidores></consumidores>    
@endsection