<template>
  <div class="ma-0 pa-0">
    <template>
      <v-row>
        <v-col cols="12" class="pa-0">        
          <v-img src="images/Slides/BannerInicio.png" class="d-block" max-height="513">
          </v-img>
        </v-col>
      </v-row>
      
      <v-row class="yellow darken-1">
        <v-container>
          <v-row>
            <v-col cols="12">
              <h1 class="text-center text-lg title">Que productos puedes encontrar en este mercado</h1>
              <v-divider class="green accent-2"></v-divider>
            </v-col>
            <v-col cols="12" md="6">
              <p class="text-center font-weight-bold text-md body-1">
                En este mercado encontraras los vegetales entre frutas ya sean secos o frescos. Las verduras chinas o 
                criollas. Además, entre lacteos y derivados como queso, yogurth. También, puedes encontrar la sección de carnes
                con pollos en trozos o enteros; res molido, trozo o lomitos; cerdo ya sea en chuletas. Y la sección de mariscos y pescados.
                Por otra parte, encontraras la sección de pastelería para tus postres dulces o salados y entre golosinas.
              </p>
            </v-col>
            <v-col cols="12" md="6">
              <p class="text-center font-weight-bold text-md"> 
                FRUTAS <br>
                VERDURAS <br>
                CARNES POLLO/RES/CERDO <br>
                PESCADOS Y MARISCOS <br>
                PASTELERIA Y GOLOSINAS <br>
                ABARROTES <br>
              </p>
            </v-col>
          </v-row>
        </v-container>
      </v-row>
    </template>
  </div>
</template>
