
<?php $__env->startSection('content'); ?>
    <!-- <?php if(isset($Titulo)): ?>
        <v-snackbar
        class="mt-7"
        v-model="snackbar"
        right
        top
        color="info"
        vertical
        >
        <?php echo e($Titulo); ?>

        <br>
        <v-btn
            dark
            text
            @click="snackbar = false"
        >
            Cerrar
        </v-btn>
        </v-snackbar>
    <?php endif; ?> -->
    <registro-puesto id_user="<?php echo e(auth()->user()->id); ?>" ></registro-puesto>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\Laravel\apay\resources\views/comerciante/registro_puesto.blade.php ENDPATH**/ ?>