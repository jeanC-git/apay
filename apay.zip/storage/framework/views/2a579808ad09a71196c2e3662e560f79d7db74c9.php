
<?php $__env->startSection('content'); ?>
    <?php if(@Auth::user()->hasRole('consumidor')): ?>
    <home-consumidor></home-consumidor>
    <?php elseif(@Auth::user()->hasRole('comerciante')): ?>
    <home-comerciante></home-comerciante>

    <?php elseif(@Auth::user()->hasRole('administrador')): ?>
        <consumidores></consumidores>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\Laravel\apay\resources\views/home.blade.php ENDPATH**/ ?>