
<?php $__env->startSection('content'); ?>
    <productos id_user="<?php echo e(auth()->user()->id); ?>"></productos>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\Laravel\apay\resources\views/comerciante/mis-productos.blade.php ENDPATH**/ ?>