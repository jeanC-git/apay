<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons' rel=”stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
</head>
<body>
    <v-app id="app">
        <template>
            <v-app id="inspire">
                <v-navigation-drawer v-model="drawer" :clipped="$vuetify.breakpoint.lgAndUp" app color="#A0FFE1">
                    <template >
                        <v-list>
                            <v-list-item-group>
                                <?php echo $__env->make('layouts.v-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                                <v-list-item>
                                    <v-list-item-icon>
                                        <v-icon color="grey darken-4">mdi-logout</v-icon>
                                    </v-list-item-icon>
                                    <v-list-item-content href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                                                style="text-decoration: none; color:black">
                                        <v-list-item-title>
                                                Cerrar Sesión
                                        </v-list-item-title>
                                    </v-list-item-content>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </v-list-item>
                            </v-list-item-group>
                        </v-list>
                    </template>
                </v-navigation-drawer>
                <v-app-bar :clipped-left="$vuetify.breakpoint.lgAndUp" app color="#69F0AE" dark>
                    <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
                    <v-toolbar-title style="width: 300px" class="ml-0 pl-4">
                        <span style='color : #9F9E9D' class="hidden-sm-and-down">Bienvenido, <?php echo e(auth()->user()->name); ?></span>
                    </v-toolbar-title>
                    
                    <v-spacer></v-spacer>
                    <v-btn icon>
                        <v-icon>mdi-bell</v-icon>
                    </v-btn>
                    <v-btn icon large>
                        <v-avatar size="42px" item>
                            <v-img src="\images\icons\icon-72x72.png" alt=""></v-img>
                        </v-avatar>
                    </v-btn>
                </v-app-bar>
                <v-content>
                    <v-container class="fill-height" fluid>
                        <?php echo $__env->yieldContent('content'); ?>
                    </v-container>
                </v-content>
            </v-app>
        </template>
    </v-app>

</body>
</html>
<?php /**PATH C:\Proyectos\Laravel\apay\resources\views/layouts/app.blade.php ENDPATH**/ ?>